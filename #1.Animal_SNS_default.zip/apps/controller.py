# -*- coding: utf-8 -*-
from flask import Flask, request, render_template, jsonify
from apps import app


@app.route('/')
def index():
    # return render_template('login.html')
    return render_template('mypage01.html')